package com.rujikasajeev.dsrecyclerview;

import android.view.View;

/**
 * Created by pc on 2/28/2018.
 */
public interface ClickListener {
    public void onItemClick(View view, int position);

    public void onLongItemClick(View view, int position);
}
