package com.rujikasajeev.dsrecyclerview;

import android.content.Intent;
import android.graphics.Movie;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Context;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Support> supportList = new ArrayList<>();
    private RecyclerView recyclerView;
    private SupportAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        mAdapter = new SupportAdapter(supportList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL, 16));
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnItemTouchListener(new SupportTouchListener(getApplicationContext(), recyclerView, new ClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Toast.makeText(MainActivity.this, "Clicked Position :" + position, Toast.LENGTH_SHORT).show();
                /*Intent intent = null;
                switch (position) {
                    case 0:
                        intent = new Intent(MainActivity.this, MenuActivity.class);
                        startActivity(intent);
                        break;

                }


            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));*/
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));

        prepareSupportData();

    }


            private void prepareSupportData() {
        Support support = new Support("Education", "Schemes", "Schemes");
        supportList.add(support);

        support = new Support("Sports", "Schemes", "Schemes");
        supportList.add(support);

        support = new Support("Entrepreneurship", "Schemes", "Schemes");
        supportList.add(support);

        support = new Support("Empowerment", "Schemes", "Schemes");
        supportList.add(support);

        support = new Support("Others", "Schemes", "Schemes");
        supportList.add(support);

        /*support = new Support("Mission: Impossible Rogue Nation", "Action", "2015");
        supportList.add(support);

        support = new Support("Up", "Animation", "2009");
        supportList.add(support);

        support= new Support("Star Trek", "Science Fiction", "2009");
        supportList.add(support);

        support = new Support("The LEGO Movie", "Animation", "2014");
        supportList.add(support);

        support = new Support("Iron Man", "Action & Adventure", "2008");
        supportList.add(support);

        support = new Support("Aliens", "Science Fiction", "1986");
        supportList.add(support);

        support = new Support("Chicken Run", "Animation", "2000");
        supportList.add(support);

        support = new Support("Back to the Future", "Science Fiction", "1985");
        supportList.add(support);

        support= new Support("Raiders of the Lost Ark", "Action & Adventure", "1981");
        supportList.add(support);

        support= new Support("Goldfinger", "Action & Adventure", "1965");
        supportList.add(support);

        support = new Support("Guardians of the Galaxy", "Science Fiction & Fantasy", "2014");
        supportList.add(support);*/

        mAdapter.notifyDataSetChanged();
    }

}