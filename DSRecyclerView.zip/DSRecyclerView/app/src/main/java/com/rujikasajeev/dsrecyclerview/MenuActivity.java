package com.rujikasajeev.dsrecyclerview;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;


public class MenuActivity extends AppCompatActivity implements MenuData {


    private RecyclerView.Adapter mAdapter;
    private static String LOG_TAG = "MenuActivity";

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_menu);

            RecyclerView mRecyclerView = (RecyclerView) findViewById(R.id.my_recycler_view);
            mRecyclerView.setHasFixedSize(true);
            RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
            mRecyclerView.setLayoutManager(mLayoutManager);
            mAdapter = new MenuAdapter(getDataSet());
            mRecyclerView.setAdapter(mAdapter);

            // Code to Add an item with default animation
            //((MyRecyclerViewAdapter) mAdapter).addItem(obj, index);

            // Code to remove an item with default animation
            //((MyRecyclerViewAdapter) mAdapter).deleteItem(index);
        }

        @Override
        protected void onResume() {
            super.onResume();
            ((MenuAdapter) mAdapter).setOnItemClickListener(new MenuAdapter
                    .MyClickListener() {
                @Override
                public void onItemClick(int position, View v) {
                    Log.i(LOG_TAG, " Clicked on Item " + position);
                }
            });
        }

        private ArrayList<Data> getDataSet() {
            ArrayList results = new ArrayList<Data>();

            Data obj = new Data("Support");
            results.add(obj);
            obj = new Data("Governmental Rules");
            results.add(obj);
            obj = new Data("Women Police Station");
            results.add(obj);
            obj = new Data("Women NGO's");
            results.add(obj);
            obj = new Data("Statistics");
            results.add(obj);
            obj = new Data("Women Leaders");
            results.add(obj);
            obj = new Data("Awards");
            results.add(obj);

            return results;
        }

    @Override
    public void itemClicked(View view, int position) {
        if(position==0) {
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
        }
        else if (position ==1){
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
        }

        else if (position==2){
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
        }
        else if (position==3){
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
        }
        else if (position==4){
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
        }
        else if (position==5){
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
        }
        else {
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
        }

    }

}


