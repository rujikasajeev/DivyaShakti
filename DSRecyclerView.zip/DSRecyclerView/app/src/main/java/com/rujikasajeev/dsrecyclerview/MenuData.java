package com.rujikasajeev.dsrecyclerview;

import android.view.View;

/**
 * Created by pc on 3/3/2018.
 */

interface MenuData {
    void itemClicked(View view, int position);
}
